import functions_framework
import os
import base64
import tempfile
from flask import jsonify, Request
import openai
from PyPDF2 import PdfReader

openai.api_key = os.environ.get("OPENAI_API_KEY")

def extract_text_from_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        text = ''
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text
        return text
    except Exception as e:
        return f"Error reading PDF: {str(e)}"

@functions_framework.http
def summarize_rfp(request: Request):
    if request.method != 'POST':
        return jsonify({"error": "Only POST requests are accepted"}), 405

    try:
        request_json = request.get_json(silent=True)
        if not request_json or 'fileContent' not in request_json:
            return jsonify({"error": "No file content received"}), 400

        file_content = request_json['fileContent']
        file_bytes = base64.b64decode(file_content)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
            temp_file.write(file_bytes)
            temp_path = temp_file.name

        extracted_text = extract_text_from_pdf(temp_path)
        if "Error reading PDF" in extracted_text:
            return jsonify({"error": extracted_text}), 500

        prompt = (
            "You are a helpful assistant that summarizes a Request for Proposal (RFP).\n"
            "Extract and organize the following:\n\n"
            "- Title\n"
            "- Issuing Organization\n"
            "- Closing Date and Time\n"
            "- Description of Work / Scope\n"
            "- Mandatory Requirements\n"
            "- Evaluation Criteria\n"
            "- Submission Instructions\n"
            "- Any Questions or Contact Info\n\n"
            "Respond with a clean bullet point summary."
        )

        completion = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": extracted_text[:12000]}
            ],
            temperature=0.3,
            max_tokens=800
        )

        if 'choices' not in completion or not completion['choices']:
            return jsonify({"error": "OpenAI did not return any choices"}), 500

        summary = completion['choices'][0].get('message', {}).get('content', '')

        if not summary:
            return jsonify({"error": "OpenAI returned empty summary"}), 500

        return jsonify({"summary": summary})

    except Exception as e:
        return jsonify({"error": str(e)}), 500
